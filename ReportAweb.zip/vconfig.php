<?php define('hostname','localhost');

define('usuario','id5034748_hectordavidreyes05');

define('clave','hola123');

define('namedb','id5034748_tarea10');

define('urlbase','https://probrandoprueba.000webhostapp.com/');
 ?>